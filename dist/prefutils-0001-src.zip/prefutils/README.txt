This is a separate release of a subset of the available classes in the toxiclibs library.

Only the following packages are included:

toxi.geom.*
toxi.math.*

If you're going to use these classes for Processing projects,
first drop the "geomutils" folder into the "libraries" folder of your
Processing installation. You'll then need to restart Processing in order
for it to find this new library.

Source code is available via SVN, instructions over here:
http://code.google.com/p/toxiclibs/source

JavaDocs are available in the "docs" folder:
http://code.google.com/p/toxiclibs/download/list

Have fun!

Copyright (c) 2006-2008 Karsten Schmidt <info at toxi co uk>

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

http://creativecommons.org/licenses/LGPL/2.1/

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
